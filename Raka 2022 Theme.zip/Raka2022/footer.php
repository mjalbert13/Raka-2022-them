<div class="footer">
    <h3>the footer goes here</h3>

    <?php
            wp_nav_menu(
                array(
                    'menu'=> 'footer',
                    'container'=>'',
                    'theme_location'=>'footer',
                    'container_class'=> 'raka-menu-item'
                )
            );
        ?>
</div>

<h6>© <?php echo date('Y');?>  Raka. All Rights Reserved</h6>

<?php
    wp_footer();
?>

</body>
</html>